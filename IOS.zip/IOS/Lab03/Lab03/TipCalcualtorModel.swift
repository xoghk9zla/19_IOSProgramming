//
//  TipCalcualtorModel.swift
//  tipcalc
//
//  Created by KPUGAME on 2019. 3. 21..
//  Copyright © 2019년 KPUGAME. All rights reserved.
//

import Foundation

class TipCalculatorModel{
    
    var total: Double
    var taxPct: Double
    var exchangeRate: Double
    var couponRate = [0.3, 0.5, 0.7]
    
    // initializer
    init(total: Double, taxPct: Double){
        self.total = total
        self.taxPct = taxPct
        self.exchangeRate = 1000
    }
    
    // 달러 계산 함수
    func Calc() ->[(coupon:Double, exchange:Double)]{
        var retval = [(0.0, 0.0), (0.0, 0.0), (0.0, 0.0)]
        
        for i in couponRate{
            let index = Int((i * 10 / 2) - 1)
            retval[index] = (i, exchangeRate * taxPct * (1 - i) + exchangeRate)
        }
        return retval
    }
}
