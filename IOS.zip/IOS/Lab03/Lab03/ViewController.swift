//
//  ViewController.swift
//  Lab03
//
//  Created by KPUGAME on 2019. 3. 30..
//  Copyright © 2019년 KPUGAME. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var totalTextField : UITextField!
    @IBOutlet var taxPctSlider : UISlider!
    @IBOutlet var taxPctLabel : UILabel!
    @IBOutlet var resultsTextView : UITextView!
    
    @IBAction func calculateTapped(sender : AnyObject){
        tipCalc.total = Double((totalTextField.text! as NSString).doubleValue)
        var results = ""
        
        let tax = tipCalc.Calc()
        
        for (coupon, exchange) in tax{
            results += "\(Int(coupon * 100))% 쿠폰: \(Int(tipCalc.total / exchange))달러 환전 가능\n"
        }
        
        resultsTextView.text = results

    }
    @IBAction func taxPercentageChanged(sender : AnyObject){
        tipCalc.exchangeRate = Double(taxPctSlider.value)
        print("\(tipCalc.exchangeRate),  \(tipCalc.taxPct)")
        refreshUI()
    }
    
    @IBAction func viewTapped(sender : AnyObject){
        totalTextField.resignFirstResponder()
    }
    
    let tipCalc = TipCalculatorModel(total: 2000.00, taxPct: 0.02)
    
    func refreshUI(){
        totalTextField.text = String(format: "%0.2f", tipCalc.total)
        taxPctSlider.value = Float(tipCalc.exchangeRate)
        taxPctLabel.text = "원/달러 (\(Float(taxPctSlider.value)))"
        resultsTextView.text = ""
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        refreshUI()
    }


}

