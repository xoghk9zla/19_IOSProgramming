//
//  GraphView.swift
//  Flo
//
//  Created by KPUGAME on 2019. 6. 13..
//  Copyright © 2019년 KPUGAME. All rights reserved.
//

import UIKit

class GraphView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
