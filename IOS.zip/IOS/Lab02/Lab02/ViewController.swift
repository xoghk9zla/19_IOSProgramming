//
//  ViewController.swift
//  Lab02
//
//  Created by KPUGAME on 2019. 3. 23..
//  Copyright © 2019년 KPUGAME. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var ShowLabel: UILabel!
    
    var newOperation = true
    var labeltext = ""
    
    func AddNumberToInput(number: String){
        var textNumber = String(ShowLabel.text!)
        
        if newOperation{
            textNumber = ""
            newOperation = false
        }
        
        textNumber = textNumber + number    
        ShowLabel.text = textNumber
    }
    
    @IBAction func btn0(_ sender: UIButton){
        AddNumberToInput(number: "0")
    }
    @IBAction func btn1(_ sender: UIButton){
        AddNumberToInput(number: "1")
    }
    @IBAction func btn2(_ sender: UIButton){
        AddNumberToInput(number: "2")
    }
    @IBAction func btn3(_ sender: UIButton){
        AddNumberToInput(number: "3")
    }
    @IBAction func btn4(_ sender: UIButton){
        AddNumberToInput(number: "4")
    }
    @IBAction func btn5(_ sender: UIButton){
        AddNumberToInput(number: "5")
    }
    @IBAction func btn6(_ sender: UIButton){
        AddNumberToInput(number: "6")
    }
    @IBAction func btn7(_ sender: UIButton){
        AddNumberToInput(number: "7")
    }
    @IBAction func btn8(_ sender: UIButton){
        AddNumberToInput(number: "8")
    }
    @IBAction func btn9(_ sender: UIButton){
        AddNumberToInput(number: "9")
    }
    
    var op = "+"
    var number1 : Double?
    
    // *
    @IBAction func btnMul(_ sender: UIButton){
        op = "*"
        number1 = Double(ShowLabel.text!)
        newOperation = true
        ShowLabel.text = "\(number1!) *"
    }
    
    // /
    @IBAction func btnDiv(_ sender: UIButton){
        op = "/"
        number1 = Double(ShowLabel.text!)
        newOperation = true
        ShowLabel.text = "\(number1!) /"
    }
    
    // +
    @IBAction func btnAdd(_ sender: UIButton){
        op = "+"
        number1 = Double(ShowLabel.text!)
        newOperation = true
        ShowLabel.text = "\(number1!) +"
    }
    
    // -
    @IBAction func btnSub(_ sender: UIButton){
        op = "-"
        number1 = Double(ShowLabel.text!)
        newOperation = true
        ShowLabel.text = "\(number1!) -"
    }
    
    // =
    @IBAction func btnEqual(_ sender: UIButton){
        let number2 = Double(ShowLabel.text!)
        var results : Double?
        
        switch op {
        case "*":
            results = number1! * number2!
            ShowLabel.text = "\(number1!) * \(number2!) = \(results!)"
        case "/":
            results = number1! / number2!
            ShowLabel.text = "\(number1!) / \(number2!) = \(results!)"
        case "+":
            results = number1! + number2!
            ShowLabel.text = "\(number1!) + \(number2!) = \(results!)"
        case "-":
            results = number1! - number2!
            ShowLabel.text = "\(number1!) - \(number2!) = \(results!)"
        
        default:
            results = 0.0
        }
        //ShowLabel.text = String(results!)
        newOperation = true
    }
    
    // C
    @IBAction func btnC(_ sender: UIButton){
        ShowLabel.text = "0"
        newOperation = true
    }
    
    // .
    @IBAction func btnDot(_ sender: UIButton){
        AddNumberToInput(number: ".")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

