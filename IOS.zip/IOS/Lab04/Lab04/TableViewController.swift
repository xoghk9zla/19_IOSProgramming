//
//  TableViewController.swift
//  Lab04
//
//  Created by KPUGAME on 2019. 4. 4..
//  Copyright © 2019년 KPUGAME. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {

    @IBOutlet var totalTextField : UITextField!
    
    @IBOutlet var taxPctSlider : UISlider!
    @IBOutlet var yen_taxPctSlider : UISlider!
    @IBOutlet var eur_taxPctSlider : UISlider!
    
    @IBOutlet var taxPctLabel : UILabel!
    @IBOutlet var yen_taxPctLabel : UILabel!
    @IBOutlet var eur_taxPctLabel : UILabel!
    
    @IBOutlet var resultsTextView : UITextView!
    @IBOutlet var yen_resultsTextView : UITextView!
    @IBOutlet var eur_resultsTextView : UITextView!
    
    @IBAction func calculateTapped(sender : AnyObject){
        tipCalc.total = Double((totalTextField.text! as NSString).doubleValue)
        var results = ""
        var yen_results = ""
        var eur_results = ""
        
        let tax = tipCalc.Calc()
        let yen_tax = tipCalc.yen_Calc()
        let eur_tax = tipCalc.eur_Calc()
        
        for (coupon, exchange) in tax{
            results += "\(Int(coupon * 100))% 쿠폰: \(Int(tipCalc.total / exchange))달러 환전 가능\n"
        }
        for (coupon, exchange) in yen_tax{
            yen_results += "\(Int(coupon * 100))% 쿠폰: \(Int(tipCalc.total / exchange))엔 환전 가능\n"
        }
        for (coupon, exchange) in eur_tax{
            eur_results += "\(Int(coupon * 100))% 쿠폰: \(Int(tipCalc.total / exchange))유로 환전 가능\n"
        }
        
        resultsTextView.text = results
        yen_resultsTextView.text = yen_results
        eur_resultsTextView.text = eur_results
    }
    
    @IBAction func taxPercentageChanged(sender : AnyObject){
        tipCalc.exchangeRate = Double(taxPctSlider.value)
        print("\(tipCalc.exchangeRate),  \(tipCalc.taxPct)")
        refreshUI()
    }
    @IBAction func yen_taxPercentageChanged(sender : AnyObject){
        tipCalc.yen_exchangeRate = Double(yen_taxPctSlider.value)
        print("\(tipCalc.yen_exchangeRate),  \(tipCalc.taxPct)")
        refreshUI()
    }
    @IBAction func eur_taxPercentageChanged(sender : AnyObject){
        tipCalc.eur_exchangeRate = Double(eur_taxPctSlider.value)
        print("\(tipCalc.eur_exchangeRate),  \(tipCalc.taxPct)")
        refreshUI()
    }
    @IBAction func viewTapped(sender : AnyObject){
        totalTextField.resignFirstResponder()
    }
    
    let tipCalc = TipCalculatorModel(total: 2000.00, taxPct: 0.02)
    
    func refreshUI(){
        totalTextField.text = String(format: "%0.2f", tipCalc.total)
        taxPctSlider.value = Float(tipCalc.exchangeRate)
        taxPctLabel.text = "원/달러: (\(Float(taxPctSlider.value)))"
        yen_taxPctSlider.value = Float(tipCalc.yen_exchangeRate)
        yen_taxPctLabel.text = "원/엔: (\(Float(yen_taxPctSlider.value)))"
        eur_taxPctSlider.value = Float(tipCalc.eur_exchangeRate)
        eur_taxPctLabel.text = "원/유로: (\(Float(eur_taxPctSlider.value)))"
        resultsTextView.text = ""
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 4
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 2
    }

    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
