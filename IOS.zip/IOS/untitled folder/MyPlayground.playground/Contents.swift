import UIKit

var str = "Hello, playground"
2+2

var age: Int = 20

var luckynumber = 7


