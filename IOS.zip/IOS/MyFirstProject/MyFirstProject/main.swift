//
//  main.swift
//  MyFirstProject
//
//  Created by KPUGAME on 2019. 3. 14..
//  Copyright © 2019년 KPUGAME. All rights reserved.
//

import Foundation

func input() -> String {
    let keyboard = FileHandle.standardInput
    let inputData = keyboard.availableData
    let rawString = NSString(data: inputData, encoding:String.Encoding.utf8.rawValue)
    if let string = rawString {
        return string.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
    } else {
        return "Invalid input"
    }
}

func randomIntBetween(low:Int, high:Int) -> Int {
    let range = high - (low - 1)
    return (Int(arc4random()) % range) + (low - 1)
}

let answer = randomIntBetween(low: 1, high: 100)

var turn = 1

while(true){
    print("Guess #\(turn):Enter a number between 1 and 100.")

    let userInput = input()
    
    let inputAsInput = Int(userInput)

    if let guess = inputAsInput{
        if (guess > answer){
            print("Lower!")
        }
        else if(guess < answer){
            print("Higher!")
        }
        else{
            print("Correct! The answer was \(answer).")
            break
        }
    }
    else{
        print("Invalid input! Please enter a number!")
        continue
    }
    turn = turn + 1
}
print("It took you \(turn) tries.")
