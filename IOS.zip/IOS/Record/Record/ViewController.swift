//
//  ViewController.swift
//  Record
//
//  Created by KPUGAME on 2019. 4. 29..
//  Copyright © 2019년 KPUGAME. All rights reserved.
//

import UIKit
import AVFoundation
import Speech

class ViewController: UIViewController, AVAudioPlayerDelegate, AVAudioRecorderDelegate {
    
    var audioPlayer: AVAudioPlayer?
    var audioRecorder: AVAudioRecorder?
    
    /*
    let recognizer = SFSpeechRecognizer()
    let request = SFSpeechURLRecognitionRequest(url: fileUrl)
    recognizer?.recognitionTask(with: request, resultHandler: {(result, error) in print(result?.bestTranscription.formattedString)})
    */
    @IBOutlet weak var Play: UIButton!
    @IBOutlet weak var Record: UIButton!
    @IBOutlet weak var Stop: UIButton!
    @IBOutlet weak var transcribeButton: UIButton!
    @IBOutlet weak var textView: UITextView!
    
    @IBAction func RecordAudio(_ sender: Any) {
        if audioRecorder?.isRecording == false{
            Play.isEnabled = false
            Stop.isEnabled = true
            audioRecorder?.record()
        }
    }
    @IBAction func StopAudio(_ sender: Any) {
        Stop.isEnabled = false
        Play.isEnabled = true
        Record.isEnabled = true
        
        if audioRecorder?.isRecording == true{
            audioRecorder?.stop()
        } else{
            audioPlayer?.stop()
        }
    }
    @IBAction func PlayAudio(_ sender: Any) {
        if audioRecorder?.isRecording == false{
            Stop.isEnabled = true
            Record.isEnabled = false
            
            do {
                try audioPlayer = AVAudioPlayer(contentsOf: (audioRecorder?.url)!)
                audioPlayer!.delegate = self
                audioPlayer!.prepareToPlay()
                audioPlayer!.play()
            } catch let error as NSError{
                print("audioPlayer error: \(error.localizedDescription)")
            }
        }
    }
    @IBAction func transcribeAudio(_ sender: Any) {
        let recongizer = SFSpeechRecognizer(locale: Locale(identifier: "ko-KR"))!
        let request = SFSpeechURLRecognitionRequest(url: (audioRecorder?.url)!)
        
        recongizer.recognitionTask(with: request, resultHandler: { (result, error) in self.textView.text = result?.bestTranscription.formattedString
        })
        
        
    }
    
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        Record.isEnabled = true
        Stop.isEnabled = false
    }
    
    func audioPlayerDecodeErrorDidOccur(_ player: AVAudioPlayer, error: Error?) {
        print("Audio Play Decode Error")
    }
    
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
    }
    
    func audioRecorderEncodeErrorDidOccur(_ recorder: AVAudioRecorder, error: Error?) {
        print("Audio Record Encode Error")
    }
    
    func authorizeSR(){
        SFSpeechRecognizer.requestAuthorization{ authStatus in OperationQueue.main.addOperation{
            switch authStatus{
            case .authorized:
                self.transcribeButton.isEnabled = true
                
            case .denied:
                self.transcribeButton.isEnabled = false
                self.Record.setTitle("Speech recognition access denied by user", for: .disabled)
                
            case .restricted:
                self.transcribeButton.isEnabled = false
                self.transcribeButton.setTitle("Speech recognition not authorized", for: .disabled)
                
            case .notDetermined:
                self.transcribeButton.isEnabled = false
                self.transcribeButton.setTitle("Speech recognition not authorized", for: .disabled)
            }
            
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Play.isEnabled = false
        Stop.isEnabled = false
        
        let fileMgr = FileManager.default
        let dirPaths = fileMgr.urls(for: .documentDirectory, in: .userDomainMask)
        let soundFileURL = dirPaths[0].appendingPathComponent("sound.caf")
        
        let recordSettings = [AVEncoderAudioQualityKey: AVAudioQuality.min.rawValue, AVEncoderBitRateKey: 16, AVNumberOfChannelsKey: 2, AVSampleRateKey: 44100.0] as [String: Any]
        
        let audioSession = AVAudioSession.sharedInstance()
        
        do{
            try audioSession.setCategory(AVAudioSession.Category.playAndRecord, mode: AVAudioSession.Mode.default, options: AVAudioSession.CategoryOptions.defaultToSpeaker)
        } catch let error as NSError{
            print("audioSession error: \(error.localizedDescription)")
        }
        
        do{
            try audioRecorder = AVAudioRecorder(url: soundFileURL, settings: recordSettings as [String: AnyObject])
            
            audioRecorder?.prepareToRecord()
        } catch let error as NSError{
            print("audioSession error: \(error.localizedDescription)")
        }
        
        authorizeSR()
    }


}

