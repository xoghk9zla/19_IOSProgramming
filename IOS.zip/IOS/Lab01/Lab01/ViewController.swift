//
//  ViewController.swift
//  Lab01
//
//  Created by KPUGAME on 2019. 3. 20..
//  Copyright © 2019년 KPUGAME. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var TimerLabel: UILabel!
    
    // timer를 사용하기 위한 변수 선언
    var tenmins = 0
    var unitmins = 0
    var tenseconds = 0
    var unitseconds = 0
    var milliseconds = 0
    var timer = Timer()
    
    @objc func addTime()
    {
        if milliseconds == 9{
            milliseconds = 0
            if unitseconds == 9{
                unitseconds = 0
                if tenseconds == 5{
                    tenseconds = 0
                    if unitmins == 9{
                        unitmins = 0
                        tenmins += 1
                    }
                    else{
                        unitmins += 1
                    }
                }
                else{
                    tenseconds += 1
                }
            }
            else{
                unitseconds += 1
            }
        }
        
        milliseconds += 1
        
        
        TimerLabel.text = "Time: \(tenmins)\(unitmins):\(tenseconds)\(unitseconds):\(milliseconds)"
    }
    
    @IBAction func StartButton(){
        timer.invalidate()
        TimerLabel.text = "Time: \(tenmins)\(unitmins):\(tenseconds)\(unitseconds):\(milliseconds)"
        
        timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(self.addTime), userInfo: nil, repeats: true)
        // 콘솔 창에 출력
        NSLog("Button Pressed")
    }
    @IBAction func StopButton(){
        timer.invalidate()
        // 콘솔 창에 출력
        NSLog("Button Pressed")
    }
    @IBAction func ResetButton(){
        timer.invalidate()
        tenmins = 0
        unitmins = 0
        tenseconds = 0
        unitseconds = 0
        milliseconds = 0
        TimerLabel.text = "Time: \(tenmins)\(unitmins):\(tenseconds)\(unitseconds):\(milliseconds)"
        // 콘솔 창에 출력
        NSLog("Button Pressed")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

