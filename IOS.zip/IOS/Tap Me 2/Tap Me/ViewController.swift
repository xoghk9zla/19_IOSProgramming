//
//  ViewController.swift
//  Tap Me
//
//  Created by KPUGAME on 2019. 3. 14..
//  Copyright © 2019년 KPUGAME. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var scoreLabel: UILabel!
    @IBOutlet var timerLabel: UILabel!
    
    // score를 관리하는 변수 선언
    var count = 0
    
    // timer를 사용하기 위한 변수 2개 선언
    var seconds = 0
    var timer = Timer()
    
    func setupGame(){
        seconds = 30
        count = 0
        
        timerLabel.text = "Time: \(seconds)"
        scoreLabel.text = "Score \n\(count)"
        
        // timer 설정
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.subtractTime), userInfo: nil, repeats: true)
    }
    
    @objc func subtractTime(){
        seconds -= 1
        timerLabel.text = "Time: \(seconds)"
        
        if(seconds == 0){
            // timer 정지
            timer.invalidate()
            
            // alert 메세지 출력
            let alert = UIAlertController(title: "Time is up!", message: "You scored \(count) points", preferredStyle: UIAlertController.Style.alert)
            
            // Play Again버튼을 추가하고 버튼이 눌리면 setupGame를 다시 실행하도록 설정
            alert.addAction(UIAlertAction(title:"Play Again", style: UIAlertAction.Style.default, handler:{action in self.setupGame()
                
            }))
            // alert 메시지를 앱에서 보이도록 추가
            present(alert, animated: true, completion: nil)
        }
    }
    
    // 버튼을 누르면 실행되는 메소드 추가
    @IBAction func buttonPressed(){
        count += 1
        
        // scoreLabel 텍스트 변경
        scoreLabel.text = "Score \n\(count)"
        
        // 콘솔 창에 출력
        NSLog("Button Pressed")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        setupGame()
    }


}

