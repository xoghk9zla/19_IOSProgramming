//
//  StopwatchView.swift
//  Anagrams
//
//  Created by KPUGAME on 2019. 5. 20..
//  Copyright © 2019년 Caroline. All rights reserved.
//

import Foundation
import UIKit

class StopWathView: UILabel{
    required init?(coder aDecoder: NSCoder) {
        fatalError("use init(fram: )")
    }
    
    override init(frame: CGRect) {
        super.init(frame:frame)
        
        self.backgroundColor = UIColor.clear
        self.font = FontHUDBig
    }
    
    func setSeconds(_ seconds:Int ){
        self.text = String(format: "%02i : %02i", seconds / 60, seconds % 60)
    }
}
