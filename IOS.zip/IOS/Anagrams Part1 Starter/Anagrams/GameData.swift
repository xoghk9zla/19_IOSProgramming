//
//  GameData.swift
//  Anagrams
//
//  Created by KPUGAME on 2019. 5. 20..
//  Copyright © 2019년 Caroline. All rights reserved.
//

import Foundation

class GameData{
    var points: Int = 0{
        didSet{
            points = max(points, 0)
        }
    }
}
