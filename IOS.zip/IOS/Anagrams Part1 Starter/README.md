# Anagram-Swift-3-XCode-8
Simple game using Swift 3 and XCode 8 following the tutorial from https://www.raywenderlich.com/77981/make-letter-word-game-uikit-swift-part-1
