//
//  ViewController.swift
//  Tap Me
//
//  Created by KPUGAME on 2019. 3. 14..
//  Copyright © 2019년 KPUGAME. All rights reserved.
//

import UIKit
// 오디오를 위한 import
import AVFoundation

class ViewController: UIViewController {
    @IBOutlet var scoreLabel: UILabel!
    @IBOutlet var timerLabel: UILabel!
    
    var buttonBeep : AVAudioPlayer?
    var secondBeep : AVAudioPlayer?
    var backgroundMusic : AVAudioPlayer?
    
    // score를 관리하는 변수 선언
    var count = 0
    
    // timer를 사용하기 위한 변수 2개 선언
    var seconds = 0
    var timer = Timer()
    
    func setupGame(){
        seconds = 30
        count = 0
        
        timerLabel.text = "Time: \(seconds)"
        scoreLabel.text = "Score \n\(count)"
        
        // timer 설정
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.subtractTime), userInfo: nil, repeats: true)
        
        // 배경음악
        backgroundMusic?.volume = 0.3
        backgroundMusic?.play()
    }
    
    @objc func subtractTime(){
        seconds -= 1
        timerLabel.text = "Time: \(seconds)"
        
        // 초가 감소할 때마다 사운드 실행
        secondBeep?.play()
        
        if(seconds == 0){
            // timer 정지
            timer.invalidate()
            
            // alert 메세지 출력
            let alert = UIAlertController(title: "Time is up!", message: "You scored \(count) points", preferredStyle: UIAlertController.Style.alert)
            
            // Play Again버튼을 추가하고 버튼이 눌리면 setupGame를 다시 실행하도록 설정
            alert.addAction(UIAlertAction(title:"Play Again", style: UIAlertAction.Style.default, handler:{action in self.setupGame()
                
            }))
            // alert 메시지를 앱에서 보이도록 추가
            present(alert, animated: true, completion: nil)
        }
    }
    
    // 버튼을 누르면 실행되는 메소드 추가
    @IBAction func buttonPressed(){
        count += 1
        
        // scoreLabel 텍스트 변경
        scoreLabel.text = "Score \n\(count)"
        
        // 콘솔 창에 출력
        NSLog("Button Pressed")
    }
    
    // 오디오를 위한 helper 함수 추가
    // file과 type 2개 인자를 받아서 AVAudioPlayer 변환
    func setupAudioPlayerWithFild(file: NSString, type: NSString) -> AVAudioPlayer? {
        // 1. Bundle.main은 앱이 있는 곳이고, 오디오 파일의 full path를 알려주면 URL형태로 변환
        let path = Bundle.main.path(forResource: file as String, ofType: type as String)
        let url = NSURL.fileURL(withPath: path!)
        
        // 2. optional 변수인 이유는 생성이 안될 수 있기 때문에
        var audioPlayer: AVAudioPlayer?
        do{
            try audioPlayer = AVAudioPlayer(contentsOf: url)
        }catch{
            print("Player not available")
        }
        return audioPlayer
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // 3가지 오디오 설정
        if let buttonBeep = self.setupAudioPlayerWithFild(file: "ButtonTap", type: "wav"){
            self.buttonBeep = buttonBeep
        }
        if let secondBeep = self.setupAudioPlayerWithFild(file: "SecondBeep", type: "wav"){
            self.secondBeep = secondBeep
        }
        if let backgroundMusic = self.setupAudioPlayerWithFild(file: "HallOfTheMountainKing", type: "mp3"){
            self.backgroundMusic = backgroundMusic
        }
        
        
        setupGame()
        // 프로그램에서 배경색 변경
        view.backgroundColor = UIColor.purple
        // 배경을 이미지로 변경
        view.backgroundColor = UIColor(patternImage: UIImage(named: "bg_tile.png")!)
        // 라벨의 배경도 변경
        scoreLabel.backgroundColor = UIColor(patternImage: UIImage(named: "field_score.png")!)
        timerLabel.backgroundColor = UIColor(patternImage: UIImage(named: "field_time.png")!)
        
        
    }


}

