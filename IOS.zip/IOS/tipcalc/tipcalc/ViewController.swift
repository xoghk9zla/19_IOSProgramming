//
//  ViewController.swift
//  tipcalc
//
//  Created by KPUGAME on 2019. 3. 21..
//  Copyright © 2019년 KPUGAME. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {

    // 4가지 property 선언
    @IBOutlet var totalTextField : UITextField!
    @IBOutlet var taxPctSlider : UISlider!
    @IBOutlet var taxPctLabel : UILabel!
    
    // 3가지 Action 메소드 추가
    @IBAction func calculateTapped(sender : AnyObject){
        // 1. String을 Double로 변환
        tipCalc.total = Double((totalTextField.text! as NSString).doubleValue)
        // 2. returnPossibleTips() 함수는 [Int:(tipAmt:Double, total:Double)] Dictionary 반환
        possibleTips = tipCalc.returnPossibleTips()
        sortedKeys = Array(possibleTips.keys).sorted()
        TableView.reloadData()
    }
    @IBAction func taxPercentageChanged(sender : AnyObject){
        tipCalc.taxPct = Double(taxPctSlider.value) / 100.0
        refreshUI()
    }
    @IBAction func viewTapped(sender : AnyObject){
        totalTextField.resignFirstResponder()
    }
    
    // TipCalculatorModel 의 인스턴스 생성
    @IBOutlet weak var TableView: UITableView!
    let tipCalc = TipCalculatorModel(total: 33.25, taxPct: 0.06)
    
    var possibleTips = Dictionary<Int, (tipAmt:Double, total:Double)>()
    var sortedKeys:[Int] = []
    
    // UI 초기 표시 메소드
    func refreshUI(){
        // tipCalc.total 은 Double에서 String으로 타입 변환
        totalTextField.text = String(format: "%0.2f", tipCalc.total)
        // tipCalc.taxPct 는 소수(예, 0.06)에서 정수(6%)로 변환하기 위해서 100 곱하기
        taxPctSlider.value = Float(tipCalc.taxPct) * 100.0
        // taxPctSlider.value는 float 이므로 int 로 타입 변환 후에 taxPctLabal 라벨에 반영
        taxPctLabel.text = "Tax Percentage (\(Int(taxPctSlider.value)))%"
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sortedKeys.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCell.CellStyle.value2, reuseIdentifier: nil)
        
        let tipPct = sortedKeys[indexPath.row]
        
        let tipAmt = possibleTips[tipPct]!.tipAmt
        let total = possibleTips[tipPct]!.total
        
        cell.textLabel?.text = "\(tipPct)%"
        cell.detailTextLabel?.text = String(format: "Tip: $%0.2f, total: $%0.2f", tipAmt, total)
        return cell
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        refreshUI()
    }


}

