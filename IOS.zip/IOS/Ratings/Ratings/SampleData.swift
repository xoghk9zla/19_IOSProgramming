//
//  SampleData.swift
//  Ratings
//
//  Created by KPUGAME on 2019. 3. 28..
//  Copyright © 2019년 KPUGAME. All rights reserved.
//

import Foundation

let playersData = [
    Player(name : "Bill Evans", game : "Tic-Tac-Toe", rating : 4),
    Player(name : "Oscar Peterson", game : "Spin the Bottle", rating : 5),
    Player(name : "Dave Brueck", game : "Texas Hold 'em Poker", rating : 2)
]
