//
//  PlayerCell.swift
//  Ratings
//
//  Created by KPUGAME on 2019. 3. 28..
//  Copyright © 2019년 KPUGAME. All rights reserved.
//

import UIKit

class PlayerCell: UITableViewCell {

    @IBOutlet weak var gameLable: UILabel!
    @IBOutlet weak var nameLable: UILabel!
    @IBOutlet weak var ratingImageView: UIImageView!
    
    var player:Player!{
        didSet{
            gameLable.text = player.game
            nameLable.text = player.name
            ratingImageView.image = imageForRating(rating: player.rating)
            
        }
    }
    func imageForRating(rating: Int)->UIImage?{
        let imageName = "\(rating)Stars"
        return UIImage(named: imageName)
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
