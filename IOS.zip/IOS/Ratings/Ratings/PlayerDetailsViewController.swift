//
//  PlayerDetailsViewController.swift
//  Ratings
//
//  Created by KPUGAME on 2019. 4. 1..
//  Copyright © 2019년 KPUGAME. All rights reserved.
//

import UIKit

class PlayerDetailsViewController: UITableViewController {
    @IBOutlet weak var ratingImageView: UIImageView!
    @IBOutlet weak var detailLabel: UILabel!
    @IBOutlet weak var nameTextField: UITextField!
    
    var player:Player?
    
    var game:String = "배틀그라운드"{
        didSet{
            detailLabel.text? = game
        }
    }
    
    var rating:Int = 1{
        didSet{
            ratingImageView.image? = imageForRating(rating: rating)!
        }
    }
    
    func imageForRating(rating:Int)->UIImage?{
        let imageName = "\(rating)Stars"
        return UIImage(named: imageName)
    }
    
    @IBAction func unwindWithSelectedStar(segue: UIStoryboardSegue){
        if let StarPickerViewController = segue.source as? StarPickerViewController{
            rating = StarPickerViewController.rating
        }
    }
    
    @IBAction func unwindWithSelectedGame(segue:UIStoryboardSegue){
        if let gamePickerViewController = segue.source as? GamePickerViewController,
            let selectedGame = gamePickerViewController.selectedGame{
            game = selectedGame
        }
    }
    
    // prepare 메소드는 segue실행될 때 호출되는 메소드
    // id를 SavePlayerDetail로 설정
    // 새로운 Player를 name과 "배틀그라운드", rating = 5로 생성
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "SavePlayerDetail"{
            player = Player(name: nameTextField.text!, game: game, rating: rating)
        }
        
        if segue.identifier == "PickGame"{
            if let gamePickerViewController = segue.destination as? GamePickerViewController{
                gamePickerViewController.selectedGame = game
            }
        }
        if segue.identifier == "PickStar"{
            if let starPickerViewController = segue.destination as? StarPickerViewController{
                starPickerViewController.rating = rating
            }
        }
    }
    
    // init과 deinit을 override해서 "플레이어 추가" view가 언제 메모리에 allocate되는 지 알 수 있다.
    // 실제로 + 버튼을 누른 다음에 메모리 할당 되고 Cancel 혹은 Done 버튼을 누르면 메모리가 해제된다.
    // 콘솔 창에 출력함
    required init?(coder aDecoder: NSCoder) {
        print("init PlayerDetailsViewController")
        super.init(coder: aDecoder)
    }
    deinit {
        print("deinit PlayerDetailsViewController")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        ratingImageView.image = imageForRating(rating: rating)
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    // Player Name(플레이어 이름) 섹션의 nameField의 어디를 탭해도 선택되도록 한다.
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == 0{
            nameTextField.becomeFirstResponder()
        }
    }
    
}
