import UIKit

class Person{
    var firstName = ""
    var lastName = ""
    var age = 0
    
    func input() -> String {
        let keyboard = FileHandle.standardInput
        let inputData = keyboard.availableData
        let rawString = NSString(data: inputData, encoding:String.Encoding.utf8.rawValue)
        if let string = rawString {
            return string.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        } else {
            return "Invalid input"
        }
    }
    
    func changeFirstNAme(newFirstName:String){
        firstName = newFirstName
    }
    func enterInfo(){
        print("What is the first name?")
        firstName = input()
    }
    func printInfo(){
        print("Fisrt Name: \(firstName)")
    }
}

var newPerson = Person()

newPerson.firstName = "태화"
newPerson.lastName = "김"
newPerson.age = 25

newPerson.changeFirstNAme(newFirstName: "Paul")
